<?php
namespace Drupal\example\Controller;

use Drupal\Core\Controller\ControllerBase;

class ExampleController extends ControllerBase {

  public function view() {
    return [
      '#markup' => 'Hello, world',
    ];
  }

}